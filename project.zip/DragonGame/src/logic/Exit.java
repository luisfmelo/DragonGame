package logic;

public class Exit extends Element {

	public Exit() {
		// TODO Auto-generated constructor stub
		this.setLetter('S');
	}

}
