package cli;

import logic.Game;

public class Interaction {

	public static void main(String[] args) {
		//Game Config
		/*	TODO	*/
	
		//Create Game
		Game myGame = new Game();
		
		//Run Game
		myGame.run();

	}

}
