package test;

import static org.junit.Assert.*;
import org.junit.Test;

import logic.Dragon;
import logic.Element;
import logic.Game;
import logic.Hero;
import logic.Maze;
import logic.Point;
import logic.Sword;

public class otherTest {


}
