package logic;

public class Exit extends Element {

	public Exit() {

		this.setLetter('S');

	}

}
