package test;
import static org.junit.Assert.*;
import org.junit.Test;

import logic.Element;
import logic.Game;
import logic.Hero;
import logic.Maze;
import logic.Point;

	public class HeroTest {
		
	@Test
	public void testMoveHeroToFreeCell() {
		
		Maze maze=new Maze();
		
		maze.setTestMaze();
		
		Game g= new Game(maze,1);
		assertEquals(new Point(1, 3).toString(), g.hero.pos.toString());
		g.maze.print();
		g.checkPos("A", g.hero);
		g.maze.print();
		assertEquals(new Point(1, 2).toString(),g.hero.pos.toString());

	}
	//@Test
	public void testHeroDies() {
		
		
		
		//maze.moveHeroDown();
		//assertEquals(MazeStatus.HeroDied, maze.getStatus());
	}
}
